import { useState } from "react";
import { Outlet, NavLink, useLocation } from "react-router";
import {
  LayoutDashboard,
  Mountain,
  FileBarChart2,
  Bell,
  Satellite,
  ChevronLeft,
  ChevronRight,
  Leaf,
  Settings,
  Menu,
  X,
} from "lucide-react";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/satellite", icon: Satellite, label: "Satellite Viewer" },
  { to: "/sites", icon: Mountain, label: "Mine Sites" },
  { to: "/reports", icon: FileBarChart2, label: "Reports" },
  { to: "/alerts", icon: Bell, label: "Alerts", badge: 3 },
];

export function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const currentPage = navItems.find((item) =>
    item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to)
  );

  return (
    <div className="flex h-screen bg-[#13171F] text-slate-100 overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-20 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:relative z-30 h-full flex flex-col
          bg-[#1A1F2B] border-r border-[#00FF88]/10
          transition-all duration-300 ease-in-out
          ${collapsed ? "w-16" : "w-64"}
          ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-[#00FF88]/10">
          <div className="flex-shrink-0 w-8 h-8 bg-[#00FF88] rounded-lg flex items-center justify-center">
            <Leaf className="w-5 h-5 text-[#0a0e15]" />
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <div className="text-[#00FF88] text-sm font-semibold whitespace-nowrap">RehabMonitor</div>
              <div className="text-slate-500 text-xs whitespace-nowrap">Mining & NDVI Platform</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map(({ to, icon: Icon, label, badge }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 group relative
                ${isActive
                  ? "bg-[#00FF88]/15 text-[#00FF88] border border-[#00FF88]/25"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                }`
              }
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && (
                <span className="text-sm whitespace-nowrap">{label}</span>
              )}
              {badge && !collapsed && (
                <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {badge}
                </span>
              )}
              {badge && collapsed && (
                <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {badge}
                </span>
              )}
              {collapsed && (
                <div className="absolute left-full ml-2 px-2 py-1 bg-[#252D3D] text-slate-200 text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 border border-[#00FF88]/10">
                  {label}
                </div>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Collapse button */}
        <div className="p-3 border-t border-[#00FF88]/10">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden lg:flex w-full items-center gap-3 px-3 py-2 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all"
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4 flex-shrink-0" />
            ) : (
              <>
                <ChevronLeft className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs">Collapse</span>
              </>
            )}
          </button>
          {!collapsed && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-[#00FF88]/5 border border-[#00FF88]/15">
              <div className="text-xs text-slate-500">Last sync</div>
              <div className="text-xs text-[#00FF88] mt-0.5">Today, 06:42 UTC</div>
            </div>
          )}
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex items-center gap-4 px-6 py-4 bg-[#1A1F2B]/90 backdrop-blur border-b border-[#00FF88]/10 flex-shrink-0">
          <button
            className="lg:hidden text-slate-400 hover:text-slate-200"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div>
            <h1 className="text-slate-100">{currentPage?.label ?? "Dashboard"}</h1>
            <p className="text-xs text-slate-500">
              Sentinel-2 · Landsat-8 · MODIS · {new Date().toLocaleDateString("en-AU", { dateStyle: "long" })}
            </p>
          </div>

          <div className="ml-auto flex items-center gap-3">
            {/* Status indicator */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#00FF88]/8 border border-[#00FF88]/20">
              <span className="w-2 h-2 rounded-full bg-[#00FF88] animate-pulse" />
              <span className="text-xs text-[#00FF88]">Live Feed Active</span>
            </div>

            <button className="relative p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/5">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>

            <button className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/5">
              <Settings className="w-5 h-5" />
            </button>

            <div className="w-8 h-8 rounded-full bg-[#00FF88] flex items-center justify-center text-[#0a0e15] text-xs font-semibold">
              GS
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-[#13171F]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
