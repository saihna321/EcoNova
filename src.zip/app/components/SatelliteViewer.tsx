import { useState, useRef, useEffect, useCallback } from "react";
import {
  Layers,
  ZoomIn,
  ZoomOut,
  Download,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Info,
  Eye,
  Maximize2,
  SlidersHorizontal,
  Crosshair,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const sites = [
  { id: "kal-n", name: "Kalgoorlie North", coords: "30°44'S 121°28'E", area: 124 },
  { id: "pil-w", name: "Pilbara West", coords: "21°10'S 117°12'E", area: 287 },
  { id: "mti", name: "Mount Isa Central", coords: "20°44'S 139°30'E", area: 95 },
  { id: "hun", name: "Hunter Valley", coords: "32°30'S 150°55'E", area: 212 },
  { id: "bow", name: "Bowen Basin S3", coords: "22°30'S 148°45'E", area: 341 },
];

const dateRange = [
  { label: "May 2025", ndvi: 0.48 },
  { label: "Apr 2025", ndvi: 0.46 },
  { label: "Mar 2025", ndvi: 0.43 },
  { label: "Feb 2025", ndvi: 0.40 },
  { label: "Jan 2025", ndvi: 0.36 },
  { label: "Dec 2024", ndvi: 0.38 },
  { label: "Nov 2024", ndvi: 0.35 },
  { label: "Oct 2024", ndvi: 0.32 },
];

const bandOptions = [
  { id: "ndvi", label: "NDVI", description: "Vegetation Index" },
  { id: "rgb", label: "True Color", description: "RGB Composite" },
  { id: "false", label: "False Color", description: "NIR/Red/Green" },
  { id: "swir", label: "SWIR", description: "Shortwave Infrared" },
];

const satellites = ["Sentinel-2", "Landsat-8", "MODIS"];

const imageUrls = [
  "https://images.unsplash.com/photo-1570979872224-a1ea9f1248b0?w=1080&q=80",
  "https://images.unsplash.com/photo-1776012203102-a024822685cc?w=1080&q=80",
  "https://images.unsplash.com/photo-1686011872096-4010d5203166?w=1080&q=80",
  "https://images.unsplash.com/photo-1661619135472-4c85cdb3dc90?w=1080&q=80",
];

function NDVILegend() {
  const stops = [
    { value: "< 0", color: "#1a1a7a", label: "Water" },
    { value: "0.0", color: "#8B0000" },
    { value: "0.1", color: "#FF4500" },
    { value: "0.2", color: "#FF8C00" },
    { value: "0.3", color: "#FFD700" },
    { value: "0.4", color: "#9ACD32" },
    { value: "0.5", color: "#32CD32" },
    { value: "0.6", color: "#00CC66" },
    { value: "0.7+", color: "#00FF88" },
  ];
  return (
    <div className="rounded-lg bg-[#1A1F2B]/90 border border-[#00FF88]/15 p-3">
      <div className="text-xs text-slate-400 mb-2">NDVI Scale</div>
      <div className="flex gap-0.5">
        {stops.map((s) => (
          <div key={s.value} className="flex flex-col items-center gap-1">
            <div className="w-6 h-4 rounded-sm" style={{ backgroundColor: s.color }} />
            <span className="text-[10px] text-slate-500 whitespace-nowrap">{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Simulated NDVI overlay drawn on canvas
function NDVIOverlay({ ndvi, active, opacity }: { ndvi: number; active: boolean; opacity: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !active) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    // Create a simulated NDVI heatmap
    const imageData = ctx.createImageData(W, H);

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        // Generate pseudo-random but smooth NDVI values
        const nx = x / W;
        const ny = y / H;
        // Base using sin waves for smooth variation
        const noise =
          Math.sin(nx * 8 + 1.2) * 0.15 +
          Math.sin(ny * 6 + 0.8) * 0.12 +
          Math.sin((nx + ny) * 12) * 0.08 +
          Math.sin(nx * ny * 20) * 0.05;
        const val = Math.max(-0.1, Math.min(0.9, ndvi + noise - 0.1));

        let r = 0, g = 0, b = 0;
        if (val < 0) { r = 26; g = 26; b = 122; }
        else if (val < 0.1) { r = 139; g = 0; b = 0; }
        else if (val < 0.2) { r = 255; g = 69; b = 0; }
        else if (val < 0.3) { r = 255; g = 140; b = 0; }
        else if (val < 0.4) { r = 255; g = 215; b = 0; }
        else if (val < 0.5) { r = 154; g = 205; b = 50; }
        else if (val < 0.6) { r = 50; g = 205; b = 50; }
        else if (val < 0.7) { r = 34; g = 139; b = 34; }
        else { r = 0; g = 100; b = 0; }

        const idx = (y * W + x) * 4;
        imageData.data[idx] = r;
        imageData.data[idx + 1] = g;
        imageData.data[idx + 2] = b;
        imageData.data[idx + 3] = Math.round(opacity * 255);
      }
    }
    ctx.putImageData(imageData, 0, 0);
  }, [ndvi, active, opacity]);

  if (!active) return null;

  return (
    <canvas
      ref={canvasRef}
      width={600}
      height={400}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ mixBlendMode: "multiply" }}
    />
  );
}

export function SatelliteViewer() {
  const [selectedSite, setSelectedSite] = useState(0);
  const [selectedDate, setSelectedDate] = useState(0);
  const [selectedBand, setSelectedBand] = useState("ndvi");
  const [selectedSatellite, setSelectedSatellite] = useState(0);
  const [ndviOpacity, setNdviOpacity] = useState(0.7);
  const [ndviActive, setNdviActive] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [showInfo, setShowInfo] = useState(false);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [crosshair, setCrosshair] = useState<{ x: number; y: number; ndvi: number } | null>(null);
  const viewerRef = useRef<HTMLDivElement>(null);
  const imgIdx = selectedSite % imageUrls.length;

  const currentNdvi = dateRange[selectedDate].ndvi;

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isDragging) {
        setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
      }
      // Simulate pixel probe
      if (viewerRef.current) {
        const rect = viewerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        const noise = Math.sin(x * 8) * 0.1 + Math.sin(y * 6) * 0.08;
        const ndviVal = Math.max(0, Math.min(0.9, currentNdvi + noise));
        setCrosshair({ x: e.clientX - rect.left, y: e.clientY - rect.top, ndvi: ndviVal });
      }
    },
    [isDragging, dragStart, currentNdvi]
  );

  const handleMouseUp = () => setIsDragging(false);
  const handleMouseLeave = () => { setIsDragging(false); setCrosshair(null); };

  return (
    <div className="flex h-full">
      {/* Left panel */}
      <div className="w-72 flex-shrink-0 bg-[#1A1F2B] border-r border-[#00FF88]/10 flex flex-col overflow-y-auto">
        {/* Site selector */}
        <div className="p-4 border-b border-[#00FF88]/10">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Mine Site</div>
          <div className="space-y-1">
            {sites.map((site, i) => (
              <button
                key={site.id}
                onClick={() => setSelectedSite(i)}
                className={`w-full text-left px-3 py-2.5 rounded-lg transition-all ${
                  selectedSite === i
                    ? "bg-[#00FF88]/12 border border-[#00FF88]/25 text-[#00FF88]"
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-300"
                }`}
              >
                <div className="text-sm">{site.name}</div>
                <div className="text-xs text-slate-500 mt-0.5">{site.coords} · {site.area} ha</div>
              </button>
            ))}
          </div>
        </div>

        {/* Date selector */}
        <div className="p-4 border-b border-[#00FF88]/10">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" />
            Acquisition Date
          </div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => setSelectedDate(Math.max(0, selectedDate - 1))}
              className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-white/5 disabled:opacity-30"
              disabled={selectedDate === 0}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex-1 text-center text-sm text-slate-200">{dateRange[selectedDate].label}</div>
            <button
              onClick={() => setSelectedDate(Math.min(dateRange.length - 1, selectedDate + 1))}
              className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-white/5 disabled:opacity-30"
              disabled={selectedDate === dateRange.length - 1}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {dateRange.map((d, i) => (
              <button
                key={d.label}
                onClick={() => setSelectedDate(i)}
                className={`w-full flex items-center justify-between px-3 py-1.5 rounded text-xs transition-all ${
                  selectedDate === i ? "bg-[#00FF88]/12 text-[#00FF88]" : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
                }`}
              >
                <span>{d.label}</span>
                <span className="font-mono">{d.ndvi.toFixed(2)}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Satellite source */}
        <div className="p-4 border-b border-[#00FF88]/10">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Satellite Source</div>
          <div className="flex flex-wrap gap-2">
            {satellites.map((s, i) => (
              <button
                key={s}
                onClick={() => setSelectedSatellite(i)}
                className={`px-3 py-1 rounded-full text-xs transition-all ${
                  selectedSatellite === i
                    ? "bg-blue-500/20 border border-blue-500/40 text-blue-300"
                    : "border border-slate-700 text-slate-500 hover:text-slate-300 hover:border-slate-500"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Band selector */}
        <div className="p-4 border-b border-[#00FF88]/10">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" />
            Band Composite
          </div>
          <div className="space-y-1">
            {bandOptions.map((band) => (
              <button
                key={band.id}
                onClick={() => { setSelectedBand(band.id); setNdviActive(band.id === "ndvi" || band.id === "false"); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs transition-all ${
                  selectedBand === band.id
                    ? "bg-violet-500/15 border border-violet-500/30 text-violet-300"
                    : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
                }`}
              >
                <span>{band.label}</span>
                <span className="text-slate-600">{band.description}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Overlay controls */}
        <div className="p-4">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Overlay Controls
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">NDVI Overlay</span>
              <button
                onClick={() => setNdviActive(!ndviActive)}
                className={`relative w-9 h-5 rounded-full transition-colors ${ndviActive ? "bg-[#00FF88]" : "bg-slate-700"}`}
              >
                <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-[#0a0e15] transition-transform ${ndviActive ? "translate-x-4" : ""}`} />
              </button>
            </div>
            <div>
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span>Opacity</span>
                <span>{Math.round(ndviOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={ndviOpacity}
                onChange={(e) => setNdviOpacity(Number(e.target.value))}
                className="w-full accent-[#00FF88] h-1.5"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main viewer */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Viewer toolbar */}
        <div className="flex items-center gap-2 px-4 py-2 bg-[#1A1F2B]/90 border-b border-[#00FF88]/10">
          <div className="text-sm text-slate-300">{sites[selectedSite].name}</div>
          <span className="text-slate-700">·</span>
          <div className="text-xs text-slate-500">{dateRange[selectedDate].label}</div>
          <span className="text-slate-700">·</span>
          <div className="text-xs text-slate-500">{satellites[selectedSatellite]}</div>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => setZoom(Math.min(3, zoom + 0.25))}
              className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-white/10"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
              className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-white/10"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
              className="px-2 py-1 text-xs rounded text-slate-400 hover:text-slate-200 hover:bg-white/10"
            >
              Reset
            </button>
            <button
              onClick={() => setShowInfo(!showInfo)}
              className={`p-1.5 rounded transition-colors ${showInfo ? "bg-[#00FF88]/15 text-[#00FF88]" : "text-slate-400 hover:text-slate-200 hover:bg-white/10"}`}
            >
              <Info className="w-4 h-4" />
            </button>
            <button className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-white/10">
              <Download className="w-4 h-4" />
            </button>
            <button className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-white/10">
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Viewer area */}
        <div className="flex-1 relative overflow-hidden bg-[#0d1117]">
          <div
            ref={viewerRef}
            className="absolute inset-0 cursor-crosshair"
            style={{ cursor: isDragging ? "grabbing" : "crosshair" }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
          >
            <div
              className="absolute inset-0 transition-transform"
              style={{
                transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`,
                transformOrigin: "center center",
              }}
            >
              <ImageWithFallback
                src={imageUrls[imgIdx]}
                alt={sites[selectedSite].name}
                className="w-full h-full object-cover select-none"
                draggable={false}
              />
              <NDVIOverlay ndvi={currentNdvi} active={ndviActive} opacity={ndviOpacity * 0.6} />
            </div>

            {/* Grid overlay */}
            <div
              className="absolute inset-0 pointer-events-none opacity-20"
              style={{
                backgroundImage: "linear-gradient(rgba(34,197,94,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(34,197,94,0.3) 1px, transparent 1px)",
                backgroundSize: "80px 80px",
              }}
            />

            {/* Crosshair info */}
            {crosshair && (
              <div
                className="absolute pointer-events-none"
                style={{ left: crosshair.x + 12, top: crosshair.y + 12 }}
              >
                <div className="bg-[#1A1F2B]/90 border border-[#00FF88]/30 rounded-lg p-2 text-xs text-slate-200 whitespace-nowrap">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Crosshair className="w-3 h-3 text-[#00FF88]" />
                    <span className="text-[#00FF88]">Pixel Probe</span>
                  </div>
                  <div>NDVI: <span className="text-[#00FF88]">{crosshair.ndvi.toFixed(3)}</span></div>
                  <div>X: {Math.round(crosshair.x)} Y: {Math.round(crosshair.y)}</div>
                </div>
              </div>
            )}

            {/* Corner coords */}
            <div className="absolute bottom-4 left-4 text-xs text-slate-400/70 font-mono">
              {sites[selectedSite].coords}
            </div>

            {/* Scale bar */}
            <div className="absolute bottom-4 right-4 flex items-end gap-2">
              <div className="flex flex-col items-center gap-0.5">
                <div className="h-1 w-16 bg-white/60 relative">
                  <div className="absolute left-0 top-0 h-3 w-px bg-white/60 -translate-y-1" />
                  <div className="absolute right-0 top-0 h-3 w-px bg-white/60 -translate-y-1" />
                </div>
                <span className="text-xs text-white/60">500m</span>
              </div>
            </div>
          </div>
        </div>

        {/* Info panel */}
        {showInfo && (
          <div className="bg-[#1A1F2B]/95 border-t border-[#00FF88]/10 p-4">
            <div className="grid grid-cols-4 gap-4 text-xs">
              <div>
                <div className="text-slate-500">Site Area</div>
                <div className="text-slate-200 mt-0.5">{sites[selectedSite].area} ha</div>
              </div>
              <div>
                <div className="text-slate-500">Mean NDVI</div>
                <div className="text-[#00FF88] mt-0.5">{currentNdvi.toFixed(3)}</div>
              </div>
              <div>
                <div className="text-slate-500">Acquisition</div>
                <div className="text-slate-200 mt-0.5">{dateRange[selectedDate].label}</div>
              </div>
              <div>
                <div className="text-slate-500">Resolution</div>
                <div className="text-slate-200 mt-0.5">10m × 10m</div>
              </div>
            </div>
          </div>
        )}

        {/* NDVI Legend at bottom */}
        <div className="px-4 py-3 bg-[#13171F] border-t border-[#00FF88]/10">
          <NDVILegend />
        </div>
      </div>
    </div>
  );
}